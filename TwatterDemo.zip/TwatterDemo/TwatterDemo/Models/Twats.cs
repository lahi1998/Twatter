﻿public class Twats
{
    public int Id { get; set; }
    public string? UserImg { get; set; }
    public required string Username { get; set; }
    public required string TimeOfPost { get; set; }
    public required string Content { get; set; }
}


