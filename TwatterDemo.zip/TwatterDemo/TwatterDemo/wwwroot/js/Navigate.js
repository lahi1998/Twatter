﻿document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("navigateButton").addEventListener("click", function () {
        window.location.href = '/Home/Profile'; 
    });
});
