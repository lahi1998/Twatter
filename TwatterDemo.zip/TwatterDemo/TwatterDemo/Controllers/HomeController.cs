﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using TwatterDemo.Models;

namespace TwatterDemo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            // Create a list of Twats objects
            List<Twats> twats = new List<Twats>();

            string post1time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string post2time = DateTime.Now.AddMinutes(-30).ToString("yyyy-MM-dd HH:mm:ss");

            // Use the Add method to add items to the list
            twats.Add(new Twats
            {
                Id = 1,
                Username = "User123",
                TimeOfPost = post1time,
                Content = "This is the content of the first post."
            });

            twats.Add(new Twats
            {
                Id = 2,
                Username = "User456",
                TimeOfPost = post2time,
                Content = "This is the content of the second post."
            });

            // Pass the list of twats to the view
            return View(twats);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}